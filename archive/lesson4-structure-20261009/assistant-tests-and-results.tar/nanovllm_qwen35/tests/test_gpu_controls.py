"""Host-side GPU failure protocol tests; mocks do not prove CUDA hardware recovery."""
import unittest
from types import SimpleNamespace
from unittest.mock import Mock
import torch
from qwen35_adapter.gpu_engine import GPUExecutionRunner, GPUStateManager


class GPUControlTests(unittest.TestCase):
    def make(self):
        events=[]
        states=SimpleNamespace(poisoned=False,synchronize=Mock(side_effect=lambda:events.append('sync')))
        scheduler=SimpleNamespace(admission=SimpleNamespace(states=states),
            fail_batch=Mock(side_effect=lambda *a,**k:events.append('fail')),
            postprocess=Mock(side_effect=lambda *a:events.append('post')))
        backend=SimpleNamespace(execution_mode='cuda_eager',forward=Mock(return_value=torch.zeros(1,4)),
                                compute_logits=Mock(return_value=torch.tensor([[0.,1.]])))
        runner=GPUExecutionRunner(scheduler,backend)
        runner.builder.prepare=Mock(return_value=SimpleNamespace(input_ids=torch.tensor([1]),
            last_indices=torch.tensor([0]),request_ids=(9,)))
        batch=SimpleNamespace(sequences=(SimpleNamespace(temperature=1.),),input_counts=(1,),is_prefill=True)
        return runner,scheduler,backend,states,batch,events

    def test_sync_precedes_success_settlement(self):
        runner,scheduler,backend,states,batch,events=self.make()
        self.assertEqual(runner.run(batch).token_ids,(1,))
        self.assertEqual(events,['sync','post'])

    def test_host_failure_waits_before_recycle(self):
        runner,scheduler,backend,states,batch,events=self.make()
        backend.compute_logits.side_effect=RuntimeError('host failure')
        with self.assertRaisesRegex(RuntimeError,'host failure'):runner.run(batch)
        self.assertEqual(events,['sync','fail'])
        scheduler.postprocess.assert_not_called()

    def test_sync_failure_quarantines_without_release_or_commit(self):
        runner,scheduler,backend,states,batch,events=self.make()
        backend.compute_logits.side_effect=RuntimeError('kernel fault')
        states.synchronize.side_effect=RuntimeError('device lost')
        with self.assertRaisesRegex(RuntimeError,'quarantined'):runner.run(batch)
        self.assertTrue(runner.poisoned)
        scheduler.fail_batch.assert_not_called();scheduler.postprocess.assert_not_called()
        with self.assertRaisesRegex(RuntimeError,'poisoned'):runner.run(batch)

    def test_prepare_failure_does_not_recycle(self):
        runner,scheduler,backend,states,batch,events=self.make()
        runner.builder.prepare.side_effect=ValueError('stale')
        with self.assertRaisesRegex(ValueError,'stale'):runner.run(batch)
        backend.forward.assert_not_called();scheduler.fail_batch.assert_not_called()

    def test_nan_logits_fail_batch_after_sync(self):
        runner,scheduler,backend,states,batch,events=self.make()
        backend.compute_logits.return_value=torch.tensor([[float('nan'),0.]])
        with self.assertRaisesRegex(ValueError,'invalid logits'):runner.run(batch)
        self.assertEqual(events,['sync','fail'])


if __name__=='__main__':unittest.main()
