"""Clock-controlled metric tests; no model, torch or GPU required."""
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from benchmark_gpu_baseline import percentile, run_case


class MetricsTests(unittest.TestCase):
    def fixture(self, short=False):
        requests = []
        scheduler = SimpleNamespace(completed={})
        engine = SimpleNamespace(scheduler=scheduler, runner=SimpleNamespace(capture_logits=False))
        scheduler.is_finished = lambda: not requests or len(requests[0].completion_token_ids) >= (2 if short else 3)
        def add_request(ids, sampling):
            seq = SimpleNamespace(seq_id=len(requests), completion_token_ids=[])
            requests.append(seq)
            scheduler.completed[seq.seq_id] = SimpleNamespace(reason='length')
            return seq
        def step():
            first = not requests[0].completion_token_ids
            for seq in requests:
                seq.completion_token_ids.append(42)
            return SimpleNamespace(request_ids=tuple(s.seq_id for s in requests), is_prefill=first)
        engine.add_request = add_request
        engine.step = step
        cuda = SimpleNamespace(synchronize=Mock(), reset_peak_memory_stats=Mock(),
            memory_allocated=lambda: 100, max_memory_allocated=lambda: 150,
            max_memory_reserved=lambda: 200)
        return engine, SimpleNamespace(cuda=cuda)

    def test_exact_metric_boundaries(self):
        engine, torch = self.fixture()
        with patch('benchmark_gpu_baseline.time.perf_counter', side_effect=[0, .1, 1, 1.1, 2, 2.1, 3, 3.1]):
            result = run_case(engine, [[1, 2], [3, 4]], 3, torch, SimpleNamespace)
        self.assertEqual([r['ttft_ms'] for r in result['requests']], [1000, 1000])
        self.assertEqual([r['tpot_ms'] for r in result['requests']], [1000, 1000])
        self.assertAlmostEqual(result['output_tokens_per_s'], 6 / 3.1)
        self.assertAlmostEqual(result['decode_tokens_per_s'], 2)
        self.assertEqual(result['peak_allocated_bytes'], 150)
        self.assertEqual(result['peak_reserved_bytes'], 200)
        torch.cuda.reset_peak_memory_stats.assert_called_once()

    def test_short_output_is_rejected(self):
        engine, torch = self.fixture(short=True)
        with self.assertRaises(AssertionError):
            run_case(engine, [[1]], 3, torch, SimpleNamespace)

    def test_percentile_interpolates(self):
        self.assertEqual(percentile([5, 1, 3], .5), 3)
        self.assertAlmostEqual(percentile([0, 10], .95), 9.5)


if __name__ == '__main__':
    unittest.main()
