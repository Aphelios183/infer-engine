# Lesson4验证记录

## 2026-10-08：CPU分页KV与linear状态池接线

新增9项，全套113项通过（0.319s）。PooledCPUBackend连接真实管理器、Runner输入、Full/GDN层计算与原池写回，测试多请求重排、跨块、活跃邻居隔离、非法地址和重复执行拒绝、部分写入后失败回收以及脏slot复用清零。使用小模型FP32真实计算，不是完整4B/GPU验证。详细说明见[后端核查第9节](BACKEND_AUDIT.md)。

## 2026-10-08：真实CPU层计算

新增12项测试，全套104项通过（0.182s）。独立实现norm、Q/gate、partial RoPE、Full Attention、GDN和Decoder层计算，对本机Transformers参考层验证小型随机权重的输出/缓存；FP32比较记录最大绝对差8.5682e-08。原语另覆盖BF16输入。详细阈值、范围与未接分页池/GPU/完整模型的限制见[后端核查第8节](BACKEND_AUDIT.md)。

## 2026-10-08：模型参数结构与实际加载

全套92项通过（0.206s），新增7项双分片小模型加载测试。另实际执行Qwen3.5-4B文本权重CPU加载：426/426项全字节比较通过，共8,411,510,272唯一参数字节，embedding/head为同一Parameter和存储；378项BF16、48项FP32。没有GPU或forward，运行进程已退出。源码、命令和边界见[后端核查第7节](BACKEND_AUDIT.md)。

## 2026-10-08：纯文本权重映射计划

真实checkpoint 426项文本键全部匹配名称与shape，明确忽略vision297、MTP15；共享head以别名登记。仅文件头/索引覆盖，不加载参数。9项新增单测，全套85项通过（0.045s）。命令和边界见[后端核查第6节](BACKEND_AUDIT.md)。

## 2026-10-08：CPU执行接口

全套76项通过（0.203s），新增11项。CPUExecutionRunner连接prepare、forward、最后隐藏行选择、原始logits、采样和postprocess；使用合成CPU后端验证正常与失败路径，未运行真实Qwen3.5或GPU。具体边界见[EXECUTION](EXECUTION.md)。

## 2026-10-08：RunnerInputBuilder

全套回归65项通过（0.062s），新增13项输入准备测试。消费真实HybridScheduler的pending batch，核对packed token/positions、Q/K边界、KV地址与块表、context_lens、请求state_slots和last_indices。还验证过期batch拒绝、输入准备无状态副作用及错误元数据检测。例子与运行命令见[RUNNER_INPUTS](RUNNER_INPUTS.md)。

CPU控制链已覆盖调度→输入准备→合成输出结算→释放；没有GPU传输、真实forward、采样或性能结论。后文为各阶段历史记录。

## 最新增量：HybridScheduler接线

全套CPU回归：52个测试通过（0.034s），其中新增18个Scheduler测试。直接使用真实Sequence/BlockManager、CPU StateManager和AdmissionController；token结果由测试提供，不是模型输出。覆盖共享预算、活跃上限、Decode轮转/跨块、EOS/长度/零预算生成、缺块保留历史、无进展报错、失败/取消回收、pending batch安全检查、输出校验与异常分配回滚。说明见[SCHEDULER](SCHEDULER.md)。

后文“尚未接Scheduler”属于此前历史记录。当前已接独立CPU HybridScheduler，未接LLMEngine/ModelRunner，不具备GPU安全执行或真实Qwen3.5推理能力。

## 最新增量：真实BlockManager联合准入

同一环境执行全部测试：`Ran 34 tests in 0.028s / OK`。新增10项使用真实nano Sequence/BlockManager，不是KV模拟器。覆盖正常接纳、池满回滚、部分KV分配异常、state初始化异常、前缀复用禁用与hash元数据恢复、预算背压和永久容量拒绝、重复操作与邻居隔离。执行范围是CPU管理元数据与小尺寸状态张量，未运行GPU推理。

当前副本相对最初来源另改了nanovllm/__init__.py按需加载LLM；后文“仅config.py改变”属于此前配置阶段的历史记录，不代表当前总差异。联合准入尚未接Scheduler，剩余清单见ADMISSION.md。

## 后续增量：StateManager CPU同步原型

在同一环境执行全套 `python -m unittest discover -s tests -p 'test_*.py' -v`：24个测试通过（0.043s），其中12个配置测试、12个StateManager测试。覆盖slot0、池满、重复请求、未知查询、重复释放、跨层清零、邻居隔离、batch重排、初始化中途失败回滚、dtype保留、存储别名与非法池检查。使用小尺寸CPU张量，不分配真实32层模型或GPU状态。

初始化失败测试验证所有权与空闲集合恢复；无主slot的字节可能已部分清零，重试会重新初始化，不能将此称为模型历史快照回滚。CUDA及其他非CPU设备被明确拒绝。未测试或实现GPU在途事件、多线程、陈旧generation句柄、KV联合准入和真实模型forward。

以下为此前配置契约阶段的独立记录，仍保留原结果。

日期：2026-10-07。环境：现有 `/home/ubuntu/enter/envs/nanovllm/bin/python`。仅CPU，不加载模型权重、不分配GPU缓存。

## 实际执行

在适配副本根目录运行：

```text
python -m unittest discover -s tests -p 'test_*.py' -v
Ran 12 tests in 0.003s
OK
```

真实配置CLI：

```bash
python -m qwen35_adapter --config /home/ubuntu/huggingface/Qwen3.5-4B/config.json
```

输出确认：32层、8个Full层、24个Linear层；Full原始层为[3,7,11,15,19,23,27,31]；EOS声明248044；候选每层每请求conv形状[8192,4]、recurrent形状[32,128,128]。另外执行了两张映射互斥、完整覆盖0..31和预期索引相同的断言，全部通过。

配置SHA256：`ddc63e1c717afa86c865bb5e01313d89d72bb53b97ad4a8a03ba8510c06221670`。

导入来源检查指向 `/home/ubuntu/infer-engine/nanovllm_qwen35/nanovllm/__init__.py`，只检查find_spec，不执行该包的GPU相关导入。

## 来源与安全边界验证

- 25个来源文件最初逐字节复制；再次检查原目录25个文件SHA256未改变。
- 副本中相对于来源仅nanovllm/config.py改变；新adapter/tests/docs另列，不冒充上游。
- Config入口测试用假的AutoConfig捕获越界调用，确认Qwen3.5在调用AutoConfig前抛NotImplementedError；没有启动Runner、NCCL或CUDA。
- 原模型源码文件nanovllm/models/qwen3.py已排除父目录models/忽略规则，防止遗漏源码。

## 不能推出的结论

不能推出模型数值通过、GPU状态dtype确认、Qwen3.5原生执行完成、性能收益或学生独立实作通过。原有Qwen3 GPU路径本次未回归；其源码仅增加配置类型guard，不声称完全验证兼容性。
